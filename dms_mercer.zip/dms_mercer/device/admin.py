from django.contrib import admin
from .models import *


admin.AdminSite.site_title = "Device Management Tool - Mercer"
admin.AdminSite.site_header = "Device Management Tool - Admin Panel"
admin.AdminSite.index_title = "Admin Panel"

# Register your models here.
admin.site.register(DeviceDetails)
admin.site.register(User)
