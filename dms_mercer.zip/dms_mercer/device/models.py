from django.db import models
from django.utils.timezone import now
from django.contrib.auth.models import AbstractUser


# Manager Users
class User(AbstractUser):
    manager_id = models.CharField(max_length=20, null=True, blank=True)
    manager_name = models.CharField(max_length=100, null=True, blank=True)
    location = models.CharField(max_length=100, null=True, blank=True)
    is_manager = models.BooleanField(default=False)

    USERNAME_FIELD = 'username'

    def __str__(self):
        return self.username + " _ " + self.first_name


# Manager Devices
class DeviceDetails(models.Model):
    Date = models.DateField(blank=True, null=True)
    Emp_ID = models.CharField(max_length=10)
    User_Name = models.CharField(max_length=100)
    Computer_Name = models.CharField(max_length=100)
    Gate_Pass_No = models.CharField(max_length=100)
    Desktop_Laptop_No = models.CharField(max_length=100, null=True, blank=True)
    Desktop_Laptop = models.CharField(max_length=100, null=True, blank=True)
    Monitor_Sr_No = models.CharField(max_length=100, null=True, blank=True)
    SIM = models.CharField(max_length=100, null=True, blank=True)
    Dongle = models.CharField(max_length=100, null=True, blank=True)
    Tenda_Adaptor = models.CharField(max_length=100, null=True, blank=True)
    UPS = models.CharField(max_length=100, null=True, blank=True)
    Accessories = models.CharField(max_length=100, null=True, blank=True)
    Remarks = models.CharField(max_length=255, null=True, blank=True)
    Process = models.CharField(max_length=100, null=True, blank=True)
    Department = models.CharField(max_length=100, null=True, blank=True)
    Manger_Name = models.CharField(max_length=100)
    Manager_ID = models.CharField(max_length=100)
    Comments = models.CharField(max_length=255, null=True, blank=True)
    Location = models.CharField(max_length=100, null=True, blank=True)
    Other_1 = models.CharField(max_length=100, null=True, blank=True)
    Other_2 = models.CharField(max_length=100, null=True, blank=True)
    Other_3 = models.CharField(max_length=100, null=True, blank=True)
    Other_4 = models.CharField(max_length=100, null=True, blank=True)
    Submitted_By = models.CharField(max_length=40, null=True, blank=True)
    In_TimeStamp = models.DateTimeField(null=True, blank=True)
    Status = models.CharField(max_length=40, null=True, blank=True)


    def __str__(self):
        return self.Computer_Name + self.Emp_ID


