from django.shortcuts import render, HttpResponseRedirect, reverse, HttpResponse
from .models import *
from datetime import datetime
from django.db.models import Q
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
import csv
from datetime import datetime


# Create your views here.
def login_page(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            success_msg = "Login Success !!!"
            # return render(request, 'device/index.html', {'success_msg': success_msg})
            return HttpResponseRedirect(reverse(home))
        else:
            error_msg = "Invalid Credentials !!!"
            return render(request, 'device/login.html', {'error_msg': error_msg})
    return render(request, 'device/login.html', {})


def logout_page(request):
    logout(request)
    return HttpResponseRedirect(reverse(login_page))


@login_required(login_url='/')
def home(request):
    obj_Device = DeviceDetails.objects.filter(Emp_ID=request.user.username)
    return render(request, 'device/return_device.html', {'obj_Device': obj_Device})


@login_required(login_url='/')
def view_gate_pass(request, gate_pass=None):
    username = request.user.username
    obj_Device = DeviceDetails.objects.filter(Emp_ID=username, Gate_Pass_No=gate_pass)
    return render(request, 'device/view_gate_pass.html', {'obj_Device': obj_Device})


@login_required(login_url='/')
def submit_device(request, gate_pass=None):
    username = request.user.username
    obj_Device = DeviceDetails.objects.filter((Q(Emp_ID=username) & Q(Gate_Pass_No=gate_pass)) & Q(Status='Pending') | Q(Status=None))
    if request.method == 'POST':
        comments = request.POST['comments']
        obj_Device = DeviceDetails.objects.filter(Emp_ID=username, Gate_Pass_No=gate_pass).update(Status="Submitted")
        obj_Device = DeviceDetails.objects.filter(Emp_ID=username, Gate_Pass_No=gate_pass).update(In_TimeStamp=datetime.now())
        obj_Device = DeviceDetails.objects.filter(Emp_ID=username, Gate_Pass_No=gate_pass).update(Comments=comments)
        message = "Device has been submitted successfully !!!"
        obj_Device = DeviceDetails.objects.filter(Emp_ID=username, Gate_Pass_No=gate_pass)
        return render(request, 'device/submit_device.html', {'obj_Device': obj_Device, 'message': message})
    return render(request, 'device/submit_device.html', {'obj_Device': obj_Device})


@login_required(login_url='/')
def my_team_view(request):
    obj_Device = DeviceDetails.objects.filter(Manager_ID=request.user.username).order_by('Emp_ID')
    return render(request, 'device/my_team.html', {'obj_Device': obj_Device})


@login_required(login_url='/')
def view_team_gate_pass(request, gate_pass=None):
    username = request.user.username
    obj_Device = DeviceDetails.objects.filter(Manager_ID=username, Gate_Pass_No=gate_pass)
    return render(request, 'device/view_team_gate_pass.html', {'obj_Device': obj_Device})


@login_required(login_url='/')
def submit_teams_device(request, gate_pass=None):
    obj_Device = DeviceDetails.objects.filter((Q(Manager_ID=request.user.username) & Q(Gate_Pass_No=gate_pass)) & Q(Status='Pending') | Q(Status=None))
    if request.method == 'POST':
        comments = request.POST['comments']
        obj_Device = DeviceDetails.objects.filter(Manager_ID=request.user.username, Gate_Pass_No=gate_pass).update(Status="Submitted")
        obj_Device = DeviceDetails.objects.filter(Manager_ID=request.user.username, Gate_Pass_No=gate_pass).update(In_TimeStamp=datetime.now())
        obj_Device = DeviceDetails.objects.filter(Manager_ID=request.user.username, Gate_Pass_No=gate_pass).update(Comments=comments)
        obj_Device = DeviceDetails.objects.filter(Manager_ID=request.user.username, Gate_Pass_No=gate_pass).update(Submitted_By=request.user.username)
        message = "Device has been submitted successfully !!!"
        obj_Device = DeviceDetails.objects.filter(Manager_ID=request.user.username).order_by('Emp_ID')
        return render(request, 'device/submit_device.html', {'obj_Device': obj_Device, 'message': message})
    return render(request, 'device/submit_device.html', {'obj_Device': obj_Device})


@login_required(login_url='/')
def download_page(request):
    if request.method == 'POST':
        # start_date = request.POST.get('start_date')
        # end_date = request.POST.get('end_date')
        # obj_books = Books.objects.filter(Q(Publish_Date__gte=start_date) & Q(Publish_Date__lte=end_date))
        obj_device = DeviceDetails.objects.filter(Manager_ID=request.user.username)
        meta = DeviceDetails._meta
        exclude_fields = ['id']
        field_name = [field.name for field in meta.fields if field.name not in exclude_fields]
        filename = "DeviceData_" + str(datetime.now().strftime("%d%m%Y%H%M%S")) + ".csv"
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename={}'.format(filename)
        writer = csv.writer(response)
        writer.writerow(field_name)
        for obj in obj_device:
            row = writer.writerow([getattr(obj, field) for field in field_name])
        return response
    return render(request, 'device/download_page.html', {})