from django.apps import AppConfig


class DeviceConfig(AppConfig):
    name = 'device'
