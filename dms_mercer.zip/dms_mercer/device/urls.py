from django.urls import path
from .views import *


urlpatterns = [
    path('home/', home, name='home'),
    path('login/', login_page, name='login'),
    path('', logout_page, name='logout'),
    path('download/', download_page, name='download_page'),
    path('my_team/', my_team_view, name='my_team'),
    path('my_team_view/<str:gate_pass>/', view_team_gate_pass, name='view_team_gate_pass'),
    path('my_team_submit/<str:gate_pass>/', submit_teams_device, name='submit_teams_device'),
    path('<str:gate_pass>/', view_gate_pass, name='gate_pass'),
    path('submit/<str:gate_pass>/', submit_device, name='submit_device'),

]
